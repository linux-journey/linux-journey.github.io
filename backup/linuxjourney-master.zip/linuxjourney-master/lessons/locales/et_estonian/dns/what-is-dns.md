# Mis on DNS?

## Tunni sisu

Kujutleme, et iga kord, kui on soov otsida midagi Google'is, tuleks sisestada http://192.78.12.4 mitte www.google.com. Ilma domeeninimede süsteemita (DNS) peakski just selliselt käituma. Võrgunduse alumised kihid oskavad hoste tuvastada ainult IP aadresside põhjal. DNS võimaldab inimestel pidada meeles veebilehti ja hoste nimede järgi IP aadressi asemel. See on nagu Interneti kontaktiraamat. Kui tunned kedagi nimepidi aga ei tea tema numbrit, võid telefoniraamatust lihtsalt järgi vaadata.

DNS on sisuliselt andmebaas kus hoitakse hostinimedele vastavaid IP aadresse. Üks kasutaja haldab enda andmebaasi, et teised oskaksid tema saiti/domeeni külastada ja kusagil mõni teine kasutaja haldab samal eesmärgil enda oma. Need domeenid on seeläbi võimelised üksteisega suhtlema ja moodustama massiivseid Interneti kontaktide nimekirju.

Sellel kursusel tutvustame DNS'i kohta põhilisemaid seisukohti kuid tegelikkuses on see palju laiem teema. Kui on soov DNS'i lähemalt tundma õppida tuleb täiendavalt infot juurde otsida.

## Harjutus

Harjutust pole

## Küsimus

Õige või vale? DNS aitab leida hostinimedele vastavaid MAC aadresse?

## Vastus

vale
