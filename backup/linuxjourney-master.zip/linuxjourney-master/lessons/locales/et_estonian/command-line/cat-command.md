# cat

## Tunni sisu

Me oleme failides navigeerimisega peaaegu valmis, kuid kõigepealt õpime kuidas faili lugeda. Lihtne käsk selle jaoks on cat (lühend inglisekeelsest sõnast concatenate ehk kokku kleepima). See mitte ainult ei kuva faili sisu, vaid võimaldab ka liita mitu faili kokku ja siis näidata nende kõigi sisu korraga.

<pre>$ cat koerafail linnufail</pre>

Sellega ei ole väga hea vaadata suuri faile ja on mõeldud pigem lühikese sisu kuvamiseks. Suuremate failide kuvamiseks on palju teisi tööriistu, millest räägitakse järmises peatükis.

## Harjutus

Rakendada cat käsku erinevatel failidel ja kataloogiel. Proovida käsku ka mitme faili peal korraga.

## Küsimus

Millise käsuga on hea vaadata faili sisu?

## Vastus

cat
