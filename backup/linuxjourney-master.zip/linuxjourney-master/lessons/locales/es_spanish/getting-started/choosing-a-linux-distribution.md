# Choosing a Linux Distribution

## Lesson Content

En la lección anterior, aprendimos acerca del kernel Linux el cual hace funcionar a millones de dispositivos al día. Una cosa antes de avanzar, el término Linux es un nombre equivocado, ya que en realidad se refiere al kernel Linux. De cualquier forma, muchas distribuciones utilizan el kernel Linux, por lo cual se conocen comúnmente como sistemas operativos Linux.

Un sistema operativo Linux esta dividido en tres partes principales:

<ul>
<li>Hardware - Esto incluye todo el hardware sobre el cual tu sistema se ejecuta, además de la memoria, el CPU, discos duros, etc.</li>
<li>Kernel Linux - Como lo discutimos anteriormente es el núcleo del sistema operativo. Administra el hardware y le dice como interactuar con el sistema.</li>
<li>Espacio del usuario - Este es el lugar donde los usuarios como tu interactuarán de forma directa con el sistema.</li>
</ul>

Entonces el primer paso que necesitamos tomar es instalar Linux en tu computadora. Tienes muchas opciones de las cuales elegir y este curso te ayudara a informarte y guiarte al escoger una distribución Linux.

Hay muchas distribuciones Linux de las cuales escoger, solo cubriremos las opciones mas populares.

## Excercise

No hay ejercicios para esta leccion

## Quiz Question

¡No hay preguntas, adelante!

## Quiz Answer

