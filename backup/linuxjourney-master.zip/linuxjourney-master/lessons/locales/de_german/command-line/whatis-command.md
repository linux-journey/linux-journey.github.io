# whatis

## Inhalt der Lektion

Puh, wir haben jetzt einiges über Kommandos und die Shell gelernt. Wenn du dir nichtmehr sicher bist was ein Kommando macht, kannst du das whatis Kommando benutzen. Das whatis Kommando zeigt eine kurze Beschreibung eines Kommandos an.

<pre>$ whatis cat</pre>

Dies Beschreibung kommt aus den Man Pages des Kommandos. Im Gegensatz zu man wird allerdings nur die erste Zeile angezeigt.

## Übung

Benutze das whatis Kommando für less.

## Quizfrage

Mit welchem Kommando bekommst eine kurze Beschreibung für ein Kommando?

## Quiz Antwort

whatis
