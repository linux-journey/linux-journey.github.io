﻿# Pakettide sõltuvused

## Tunni sisu

Paketid töötavad väga harva iseseisvalt, tavaliselt saadavad neid abistavad sõltuvussuhted. Näiteks võib tuua restoranide grupi kus kõik restoranid pakuvad erinevate maade ja köökide toitu kuid tooraine saavad samast farmist. Restoranide toit sõltub farmi reservist. Kui farm peaks lõpetama toorainega varustamise, siis oleksid kõik need restoranid ka väga täbaras olukorras.

Linuxis on sellisteks sõltuvusteks tavaliselt teised paketid või jagatud teegid. Jagatud teegid on ühiskasutuses olevad tarkvarakomponendid, mida teised programmid tahavad ka kasutada ilma, et peaks neid endale ümber kirjutama. Kui uuesti restoranidele mõelda siis oleks väga palju lisatööd kui iga restoran veel hakkaks ise omale toorainet kasvatama.

Jagatud teekidest tuleb lähemalt juttu failisüsteemide kursusel, hetkel peab ainult meelde jätma, et pakettidel on sõltuvussuhted, mis aitavad neil töötada. Olgu nendeks siis teised paketid või teegid - kui olulised elemendid on puudu, võib pakett sattuda katkisesse seisundisse ja üldjuhul ei saa seda üldse paigaldada.

## Harjutus

Harjutust pole.

## Küsimus

Küsimust pole.

## Vastus


