# Vim ja navigeerumine

## Tunni sisu

Võib märgata, et mitte kuskil ei kasutata hiirt. Vim'is liikumiseks sobivad järgmised klahvid:

<ul>
<li>h või vasak nooleklahv - liigutab sind ühe tähemärgi võrra vasakule</li>
<li>j või üles nooleklahv - liigutab sind ühe rea ülespoole</li>
<li>k või alla nooleklahv - liigutab sind ühe rea allapoole</li>
<li>l või paremnooleklahv - liigutab sind ühe tähemärgi võrra paremale</li>
</ul>

## Harjutus

Selles peatükis harjutust ei ole.

## Küsimus

Millise tähe klahviga saab liikuda rea allapoole?

## Vastus

k
