# Emacs redigeerimine

## Tunni sisu

<b>Tekstis liikumine</b>

<pre>
C-üles nool: liigu üks lõik üles
C-alla nool: liigu üks lõik alla
C-vasak nool: liigu üks sõna vasakule
C-parem nool: liigu üks sõna paremale
M-> : liigu puhvri lõppu
</pre>

Tekstis liikudes, töötavad tavapärased tekstiklahvid: home, end, page up, page down, nooleklahvid jne.

<b>Lõikamine ja kleepimine</b>

Et lõigata (*kill*) või kleepida (*yank*) Emacs'is, on sul vaja esiteks valida tekst. Teksti valimiseks liigu kursoriga, kus sa soovid lõigata või kleepida ja siis vajuta <pre>C-tühik</pre>. Seejärel saad kasutada navigeerimise klahve ja valida vajaliku tekstilõigu. Siis saad aga lõigata ja kleepida nõnda:

<pre>
C-w : lõika
C-y : kleebi
</pre>

## Harjutus

Tutvu tekstis liikumisega.

## Küsimus

Kuidas liikuda puhvri lõppu?

## Vastus

M->
