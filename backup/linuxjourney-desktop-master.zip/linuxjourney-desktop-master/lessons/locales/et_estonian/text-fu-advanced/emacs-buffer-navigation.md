# Emacs puhvrites navigeerimine

## Tunni sisu

Et liikuda puhvrite (või siis avatud failide) vahel kasuta järgmisi käske:

<b>Puhvri vahetamine</b>

<pre>
C-x b - vaheta puhvrit
C-x parem nooleklahv - liigu puhvritsüklis paremale
C-x vasak nooleklahv - liigu puhvritsüklis vasakule
</pre>

<b>puhvri sulgemine</b>

<pre>C-x k</pre>

<b>Poolita jooksev puhver</b>

<pre>C-x 2</pre>

See käsk võimaldab sul vaadata mitut puhvrit ühel kuval. Nende puhvrite vahel liikumiseks kasuta: C-x o

<b>Sea üksik puhver aktiivseks kuvaks</b>

<pre>C-x 1</pre>

Kui oled kunagi kasutanud terminali multiplekserit nagu screen ja tmux, siis tunduvad need puhvri käsud väga tuttavad.

## Harjutus

Mängi natuke puhvritega.

## Küsimus

Kuidas peatada puhvri töö?

## Vastus


C-x k
