# Emacs failide haldamine

## Tunni sisu

Väga suur osa (kui mitte kõik) Emacs'i dokumentatsiooni kasutab süntaksit C-[täht]. See tähendab lihtsalt Ctrl-täht, kuid lühendamise eesmärgil kirjutame Ctrl asemel C. Kui sa näed süntaksit, kus kasutatakse M-täht kirjapilti, tähendab see Meta klahvi, kõige tavalisemalt on selleks Alt.

<b>Failide salvestamine</b>

<pre>
C-x C-s - Salvesta fail
C-x C-w - Salvesta fail nimega
C-x s - Salvesta kõik
</pre>

Faili salvestamise valiku korral, avaneb iga faili salvestamisel valikuaken.

<b>Faili avamine</b>

<pre>
C-x C-f
</pre>

Küsitakse millise nimega faili soovitakse avada. Kui olemasolevat faili ei eksisteeri siis luuakse uus. Avada saab ka kataloogi. 

## Harjutus

Proovi failide avamist ja salvestamist.

## Küsimus

Millise käsuga vatake fail?

## Vastus

C-x C-f
