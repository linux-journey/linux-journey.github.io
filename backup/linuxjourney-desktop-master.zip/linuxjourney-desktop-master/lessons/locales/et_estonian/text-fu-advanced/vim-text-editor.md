# Vim (Vi Improved)

## Tunni sisu

Vim tähendab vi (Improved ehk täiustatud). Nagu nimi ütleb, on tegu vi tekstiredaktori täiustatud versiooniga.

Vim on tõeliselt väikesemahuline. Faili avamine ja muutmine vim'iga on kiire ja lihtne. See on ka peaaegu alati kättesaadav.  Tõenäoliselt on Vim pea igas Linuxis vaikimisi olemas.

Vim'i käivitamiseks sisestada: 
<pre>vim</pre>
... ja vajutada Enter-klahvi

## Harjutus

Selles peatükis harjutust ei ole.

## Küsimus

Küsimusi pole, minna julgelt edasi!

## Vastus


