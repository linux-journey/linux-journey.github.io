# Vim salvestamine ja väljumine 

## Tunni sisu

Kui teksti redigeerimine valmis, on aeg tehtud töö salvestada ja vim'ist väljuda:

<ul>
<li>:w - kirjutab või salvestab faili</li>
<li>:q - väljub vim'ist</li>
<li>:wq - kirjutab/salvestab ja siis väljub</li>
<li>:q! - väljutakse faili salvestamata</li>
<li>ZZ - võrdväärne käsuga :wq, kuid ühe tähemärgi võrra kiirem</li>

<li>u - võta tagasi viimane tegevus</li>
<li>Ctrl-r - tee uuesti viimane tagasivõtmine</li>
</ul>

Võib tunduda, et ZZ ei ole vajalik kuid praktikas on see mugavam kui :wq kasutamine.

Infot vim'i kohta on nüüd piisavalt. Nüüd kus on teada mõned peamised käsud ja osatakse liikuda, võib hakata tekstifaile redigeerima. Vim'is on veel palju võimalusi, et tõsta teksti redigeerimise meisterlikkust. Soovitame uurida <a href="http://www.vim.org/docs.php" target="_blank">Vim'i juhendeid kodulehel</a>.

## Harjutus

Selles peatükis harjutust ei ole.

## Küsimus

Kuidas väljuda vim'ist salvestamata?

## Vastus

:q!
