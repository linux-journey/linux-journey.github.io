# Linux Mint

## Tunni sisu

<b>Ülevaade</b>
Linux Mint pőhineb Ubuntul. See kasutab Ubuntu tarkvara varamuid, mistőttu on samad paketid saadaval mőlema distributsiooni jaoks. Mõned eelistavad Linux Minti Ubuntule kuna sellega ei tule kaasa patenteeritud tarkvara, näiteks Unity.

<b>Paketihaldus</b> Kuna Linux Mint põhineb Ubuntul siis see kasutab Debiani paketihaldurit.

<b>Seadistatavus</b>
Suurepärane kasutajaliides, sobiv algajatele ja kergem kasutada kui Ubuntu. Sellel kursusel hakkan mina kasutama Linux Minti, kuid iga teine distributsioon sobib samuti.

<b>Kasutusalad</b>
Sobib töölaua- ja sülearvutitele.

## Harjutus

Kui sul on huvi kasutada Linux Minti enda operatsioonisüsteemina, mine vaata paigaldusjuhist ja proovi ära: <a href='http://linuxmint.com/'>http://linuxmint.com/</a>

## Küsimus

Millel pőhineb Linux Mint?

## Vastus

Ubuntul
