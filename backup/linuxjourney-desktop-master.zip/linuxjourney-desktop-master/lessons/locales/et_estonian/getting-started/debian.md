﻿# Debian

## Tunni sisu

<b>Ülevaade</b>
Debian on operatsioonisüsteem, mis on täielikult kokku pandud vabatarkvarast. See on laialdaselt tuntud ning on olnud arenduses üle 20 aasta. Sellest on kasutamiseks kolm haru: stabiilne (Stable), arendusversioon (Testing) ja ebastabiilne (Unstable).

Stabiilne on üleüldiselt kasutamiseks hea haru. Arendusversioon ja ebastabiilne haru on jooksvad väljalasked. See tähendab, et igasugused täiendavad muutused nendes saavad kunagi stabiilseks versiooniks. Näiteks, kui sul on soov uuendada Windows 8 Windows 10ks, siis pead läbi viima täieliku Windows 10 paigaldamise. Kui sa aga alustasid juba Testing väljalaskega, saaksid sa automaatselt uuendusi, kuni lõpuks muutub see järgmiseks operatsioonisüstemi versiooniks ilma, et peaksid seda tervikuna paigaldama.

<b>Paketihaldus</b>
Debian kasutab ka Debiani paketihaldamise tööriistu. Iga Linuxi distributsioon paigaldab ja haldab pakette erinevalt ning nad kasutavad erinevaid paketihalduse tööriistu. Me süveneme sellesse teemasse rohkem hilisemal kursusel.

<b>Seadistatavus</b>
Debian ei pruugi küll saada kõige värskemaid uuendusi, kuid on sellest hoolimata äärmiselt stabiilne. Kui sa tahad head "tuumik" operatsioonisüsteemi, siis see on just sinu jaoks.

<b>Kasutusalad</b>
Debian on igakülgselt hea operatsioonisüsteem, mis sobib igale platvormile

## Harjutus
Kui sul on huvi kasutada Debiani enda operatsioonisüsteemina, mine vaata paigaldusjuhist ja proovi ära: <a href='https://www.debian.org/'>https://www.debian.org/</a>

## Küsimus

Kuidas lastakse välja arendusversiooni ja ebastabiilse versiooni harusid?

## Vastus

Jooksvalt
