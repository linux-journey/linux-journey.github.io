# Gentoo

## Tunni sisu


<b>Ülevaade</b>
Gentoo operatsioonisüsteem pakub hämmastavalt head paindlikkust mõningase pingutusega. Gentoo on loodud edasijõudnud kasutajatele, kes ei karda süsteemis käsi määrida.

<b>Paketihaldus</b>
Gentoo kasutab isiklikku paketihaldurit Portage, mis on väga modulaarne ja kergesti hallatav. Ka see mängib ka suurt rolli kogu süsteemi kui terviku paindlikusel.

<b>Seadistatavus</b>
Kui sa alles alustad Linuxiga ja tahad valida natuke keerulisema tee, siis soovitan sulle Gentoo või Arch Linuxi distributsiooni.

<b>Kasutusalad</b>
Sobib töölaua- või sülearvutile.

## Harjutus

Kui sul on huvi kasutada Debiani enda operatsioonisüsteemina, mine vaata paigaldusjuhist ja proovi ära: <a href='https://www.gentoo.org/'>https://www.gentoo.org/</a>

## Küsimus

Millist paketihaldurit Gentoo kasutab?

## Vastus

Portage
 

