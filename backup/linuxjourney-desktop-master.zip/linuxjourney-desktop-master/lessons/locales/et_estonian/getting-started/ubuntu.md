# Ubuntu

## Tunni sisu

<b>Ülevaade</b>
Üks kõige populaarsem Linuxi distributsioon personaalarvutitele on Ubuntu. Muuhulgas annab Ubuntu vaikimisi välja enda töölauakeskkonnahaldurit Unity.

<b>Paketihaldus</b>
Ubuntu on Debiani põhjal Canonicali poolt väljatöötatud operatsioonisüsteem ning kasutab seega ka Debiani keskset paketihaldussüsteemi.

<b>Seadistatavus</b>
Ubuntu on suurepärane valik igaühele, kes alles soovib Linuxiga alustada. Ubuntu pakutav kasutamise lihtsus ja suurepärane kasutajaliidese kogemus on viinud selle operatsioonisüsteemi laialdase kasutuselevõtuni.

<b>Kasutusalad</b>
Sobib igale platvormile: töölaua-, sülearvutile ja serverile.

## Harjutus

Kui sul on huvi kasutada Ubuntut enda operatsioonisüsteemina, mine vaata paigaldusjuhist ja proovi ära: <a href='http://www.ubuntu.com/'>http://www.ubuntu.com/</a>

## Küsimus

Millisel operatsioonisüsteemil põhineb Ubuntu?

## Vastus

Debian
