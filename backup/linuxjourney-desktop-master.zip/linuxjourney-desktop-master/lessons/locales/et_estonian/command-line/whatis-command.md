# whatis

## Tunni sisu

Me oleme käskude kohta juba päris palju õppinud. Kui mingil hetkel pole päris kindel, mida mõni käsk teeb, siis võib kasutada *whatis* käsku. *Whatis* kuvab lühikese kirjelduse käsurea programmi kohta.

<pre>$ whatis cat</pre>

See kirjeldus pärineb iga käsu man leheküljelt. Kui rakendada *whatis cat*, siis on näha lühikest kokkuvõtvat kirjeldust.

## Harjutus

Kasutada *whatis* käsku *ls* peal.

## Küsimus

Millist käsku saab kasutada, et näha käsu lühikirjeldust?

## Vastus

whatis

