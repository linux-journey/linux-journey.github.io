# tr (Translate)

## Tunni sisu

Tõlgendamise käsk *tr* laseb sul tõlkida mingi tähemärkide komplekti teiseks.  Proovime näteks tõlgendada kõiki väikesi tähti suurteks.

<pre>$ tr a-z A-Z
hallo
HALLO</pre>

Nagu näha siis muudeti vahemik *a-z* vahemikuks *A-Z* ja kogu väikesetäheline sisend muudeti suuretäheliseks.

## Harjutus

Proovida järgnevaid käske, vajutades rea lõpus ka Enter. Mis juhtub?

<pre>$ tr -d allo
hallo</pre>


## Küsimus

Millise käsuga tõlgendatakse ümber tähemärke?

## Vastus

*tr*
