# Linux Mint

## Lesson Content

<b>Introducción</b>
Linux Mint esta basado en Ubuntu. Utiliza los mismos repositorios de software, así que los mismos paquetes estan disponibles en ambas distribuciones. Linux Mint es preferido por alguno sobre Ubuntu porque no incluye el software propietario que Ubuntu si, tal como Unity.

<b>Administración de paquetes</b>
Linux Mint se basa en Ubuntu, por lo que utiliza el administrador de paquetes Debian

<b>Configurabilidad</b>
Gran interfaz de usuario, genial para principiantes y menos saturada que Ubuntu. En este curso usare Linux Mint, pero cualquier otra distribución puede ser utilizada.

<b>Usos</b>
Genial para computadoras de escritorio y laptops.

## Exercise

Si estas interesado en tener Linux Mint como tu sistema operativo, dirígete a la sección de instalación y dale una oportunidad: <a href='http://linuxmint.com/'>http://linuxmint.com/</a>

## Quiz Questions

¿En cuál sistema operativo esta basado Linux Mint?

## Quiz Answer

Ubuntu