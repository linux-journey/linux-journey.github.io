# Vim Navigation

## Lesson Content

Now you may notice, the mouse is nowhere is use here. To navigate a text document in vim, use the following keys: 

<ul>
<li>h or the left arrow - will move you left one character</li>
<li>j or the up arrow - will move you up one line</li>
<li>k or the down arrow - will move you down one line</li>
<li>l or the right arrow - will move you right one character</li>
</ul>

## Exercise

No exercises for this lesson.

## Quiz Question

What letter is used to move down?

## Quiz Answer

k