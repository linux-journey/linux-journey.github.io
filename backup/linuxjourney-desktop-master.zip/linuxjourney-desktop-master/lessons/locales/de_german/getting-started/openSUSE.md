# openSUSE

## Inhalt der Lektion

<b>Übersicht</b>
openSUSE Linux wird vom openSUSE Projekt gepflegt, einer Gemeinschaft die versucht die Linuxbenutztung voranzutreiben und in transparenter und offener Atmosphäre zusammenarbeitet. OpenSUSE ist die zweitälteste Linux Distribution die noch heute weiterentwickelt und gepflegt wird. OpenSUSE teilt sich das Basissystem mit dem SUSE Enterprise Linux von SUSE.

<b>Paketverwaltung</b>
Benutzt die RPM Paketverwaltung.

<b>Eigenschaften</b>

openSUSE ist eine gute Wahl für einen Linux Neuling. Es verfügt über einen einfachen grafischen Installationsvorgang und eine grafische Anwendung zur Administration des gesamten Systems namens <a href="http://yast.github.io/">YaST</a>. OpenSUSE bringt alles mit was man für den normalen Alltag braucht um das Internet ohne Viruse und Spy-Ware zu genießen und mit Fotos, Videos, Musik arbeiten zu können.

<b>Einsatz</b>

openSUSE lässt sich einfach auf einem Laptop oder Dekstop PC einsetzen.

## Übung

Wenn du dich für openSUSE interessierst findest du hier weitere Informationen: <a href='https://software.opensuse.org/'>software.opensuse.org</a>

## Quizfrage

Was ist der Name der openSUSE Administrationsanwendung?

## Quiz Antwort

yast
