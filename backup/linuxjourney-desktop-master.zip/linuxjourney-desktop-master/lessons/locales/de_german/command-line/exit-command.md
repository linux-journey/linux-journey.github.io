# exit

## Inhalt der Lektion

So, du hast gute Arbeit geleistet um dir die Grundlagen der Shell anzueignen. Wir haben allerdings nur an der Oberfläche gekratzt. Nachdem wir nun das Krabbeln gelernt haben, lernen wir in der nächsten Lektion das Laufen.

Aber erstmal darfst du dir selbst auf die Schulter klopfen und eine Pause einlegen. Um die Shell wieder zu verlassen kannst du das exit Kommando benutzen.

<pre>$ exit</pre>

Oder das logout Kommando:

<pre>$ logout</pre>

Oder falls du von einem grafischen Terminal aus arbeitest, kannst du einfach das Fenster schließen. Bis zum nächsten Kurs!

## Übung

Verlasse die Shell und schaue was passiert. Stelle sicher dass du nicht noch weitere Arbeit in dieser Shell erledigen musst.

## Quizfrage

Mit welchem Kommando kannst du die Shell verlassen?

## Quiz Antwort

exit
