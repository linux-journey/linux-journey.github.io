# man

## Inhalt der Lektion

Wem eine Kurzhilfe wie bei help nicht ausreicht, der wird vielleicht in der ausführlichen Anleitung (englisch 'man pages') fündig. Diese erreicht man mit dem man Kommando.

<pre>$ man ls</pre>

Man pages sind Anleitungen die standardmäßig in vielen Linux Distributionen mit installiert werden. Sie stellen die Dokumentation für Kommandos und das System Verfügung.

Teste es mit ein paar Kommandos um mehr über sie zu erfahren.

## Übung

Benutzte das man Kommando für das man Kommando. ;)

## Quizfrage

Mit welchem Kommando kann man sich Anleitung für ein Kommando anzeigen lassen?

## Quiz Antwort

man
