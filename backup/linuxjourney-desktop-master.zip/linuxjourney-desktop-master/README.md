# Linux Journey Desktop

This is a fork of the website LinuxJourney.com, however this is a program that you install locally on your machine, so no internet required! ^.^
I made this fork because the website is down to never return, so i decided to fork it and turn it in a desktop app

This was made with c# and avalonia


# How To Run The Program
If you're on binbows, open the desktop-app folder, then open the Program folder, then look for the .exe file and execute it!

If you're on linux, install dotnet 6, open your terminal emulator of choice, then open the desktop-app folder, then open the Scripts folder, and run the command "dotnet run"


# DON'T EXPECT GOOD CODE

This is being made with c# and avalonia, im extremely beginner when it comes to xaml (started less then a month ago), so don't expect any form of professional code from this project!!!

# THE PROGRAM IS STILL UNFINISHED AND UNUSABLE!!!
I am still working on it, at its current state, is not usable, however, once it is usable, i will come back and edit this readme *.^
